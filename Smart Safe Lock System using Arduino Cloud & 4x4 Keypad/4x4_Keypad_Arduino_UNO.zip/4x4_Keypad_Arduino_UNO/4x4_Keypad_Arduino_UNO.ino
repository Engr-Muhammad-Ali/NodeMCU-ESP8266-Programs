#include <Arduino_FreeRTOS.h>
#include <Keypad.h>

// Constants for row and column sizes
const byte ROWS = 4;
const byte COLS = 4;

// Array to represent keys on the keypad
char hexaKeys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

// Connections to Arduino
byte rowPins[ROWS] = {9, 8, 7, 6};
byte colPins[COLS] = {5, 4, 3, 2};

// Create keypad object
Keypad customKeypad = Keypad(makeKeymap(hexaKeys), rowPins, colPins, ROWS, COLS);

// Task handle for keypad scanning
TaskHandle_t TaskHandle_Keypad;

void setup() {
  // Initialize serial communication
  Serial.begin(9600);

  // Create the FreeRTOS task for keypad scanning
  xTaskCreate(TaskKeypad, "KeypadTask", 128, NULL, 1, &TaskHandle_Keypad);

  // Start the FreeRTOS scheduler
  vTaskStartScheduler();
}

// Task function to handle keypad scanning
void TaskKeypad(void *pvParameters) {
  (void) pvParameters; // Prevent unused variable warning

  for (;;) {
    char customKey = customKeypad.getKey();  // Check if a key is pressed

    if (customKey) {
      // Send the key to the NodeMCU via serial
      Serial.print(customKey);
      vTaskDelay(500 / portTICK_PERIOD_MS);  // Delay to debounce the key
    }

    // Yield the CPU to other tasks
    taskYIELD();
  }
}

void loop() {
}
